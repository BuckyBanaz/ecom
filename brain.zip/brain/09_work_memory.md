# 🧠 Work Memory Log — Antigravity Agent

This file documents the technical memory, files changed, and integration details for the SEO proxy fixes, sitemap hooks, duplicate media cleanup, and product edit lightbox zoom implemented in **v0.6**.

---

## 🔑 Files Modified

### Backend:
1. **[Caddyfile](file:///c:/Users/Parikshit/Desktop/workspace/ecom/Caddyfile)**: Rewrote bot matching regex and static asset exceptions.
2. **[seoPrerender.ts](file:///c:/Users/Parikshit/Desktop/workspace/ecom/backend/src/middlewares/seoPrerender.ts)**: Implemented escaping, dynamic hostnames, dynamic relief page mappings, and fixed Prisma field typo (`seoDesc`).
3. **[adminSettingsController.ts](file:///c:/Users/Parikshit/Desktop/workspace/ecom/backend/src/controllers/adminSettingsController.ts)**: Refactored sitemap logic and added `/relief/:slug` dynamic paths mapping.
4. **[index.ts](file:///c:/Users/Parikshit/Desktop/workspace/ecom/backend/src/index.ts)**: Hooked `rebuildSitemap()` on boot.
5. **[mediaController.ts](file:///c:/Users/Parikshit/Desktop/workspace/ecom/backend/src/controllers/mediaController.ts)**: Added recursive MD5 hash duplicate finder and database references updater.
6. **[mediaRoutes.ts](file:///c:/Users/Parikshit/Desktop/workspace/ecom/backend/src/routes/mediaRoutes.ts)**: Registered `DELETE /api/v1/media/duplicates` route.
7. **[aiService.ts](file:///c:/Users/Parikshit/Desktop/workspace/ecom/backend/src/services/aiService.ts)**: Added `regenerateImagesForProduct` to support AI image regeneration for saved products.
8. **[aiRoutes.ts](file:///c:/Users/Parikshit/Desktop/workspace/ecom/backend/src/routes/aiRoutes.ts)**: Added `POST /api/v1/ai/products/:id/regenerate-images` route.

### Frontend:
1. **[index.html](file:///c:/Users/Parikshit/Desktop/workspace/ecom/frontend/index.html)**: Added default social metadata and normalized description tag.
2. **[vite-plugin-inject-seo.ts](file:///c:/Users/Parikshit/Desktop/workspace/ecom/frontend/vite-plugin-inject-seo.ts)**: Made build-time description replacement regex-resilient.
3. **[apiClient.ts](file:///c:/Users/Parikshit/Desktop/workspace/ecom/frontend/src/client/apiClient.ts)**: Registered `mediaRepository.deleteDuplicates()` API call.
4. **[locales/en/translation.json](file:///c:/Users/Parikshit/Desktop/workspace/ecom/frontend/src/locales/en/translation.json)**: Added English translation keys for media duplicate cleanup.
5. **[locales/nl/translation.json](file:///c:/Users/Parikshit/Desktop/workspace/ecom/frontend/src/locales/nl/translation.json)**: Added Dutch translation keys for media duplicate cleanup.
6. **[MediaLibraryCore.tsx](file:///c:/Users/Parikshit/Desktop/workspace/ecom/frontend/src/components/admin/media/MediaLibraryCore.tsx)**: Added Delete Duplicates action item under the Actions dropdown toolbar.
7. **[AdminProductForm.tsx](file:///c:/Users/Parikshit/Desktop/workspace/ecom/frontend/src/pages/admin/AdminProductForm.tsx)**: Implemented lightbox modal, enabled Sparkles regenerate buttons, added active regeneration task recovery & concurrent task blocking, and added a background "Optimize with AI" button with polling status updates.
8. **[endpoints.ts](file:///c:/Users/Parikshit/Desktop/workspace/ecom/frontend/src/utils/endpoints.ts)**: Added `AI_SEO_PRODUCT_OPTIMIZE` endpoint.
9. **[translation.json (en/nl)](file:///c:/Users/Parikshit/Desktop/workspace/ecom/frontend/src/locales/en/translation.json)**: Added localization strings for product optimization tasks.
10. **[AdminProductQuickAdd.tsx](file:///c:/Users/Parikshit/Desktop/workspace/ecom/frontend/src/pages/admin/AdminProductQuickAdd.tsx)**: Integrated the MediaLibraryDialog picker to let users select product images from the storage library.

---

## 🛠️ Feature Overview & Logic

### 1. Bot Prerendering and Proxy
- **Caddybot Named Matcher**: Caddy matches request headers using standard `header_regexp` matching. Multiple UA lines are combined in a regex OR: `(?i)(googlebot|bingbot|yandex|baiduspider|twitterbot|facebookexternalhit|rogerbot|linkedinbot|embedly|quora\ link\ preview|showyoubot|outbrain|pinterest\/0\.|pinterestbot|slackbot|vkShare|W3C_Validator)`.
- **Static Assets Exclusions**: Requests ending with standard file extensions (`.js`, `.css`, `.png`, etc.) bypass the bot check and are routed directly to Nginx.
- **Dynamic Meta Lookup**: When crawlers request a `/relief/:slug` or `/blogs/:slug` or `/product/:slug` path:
  - It resolves the slug and queries database tables.
  - Corrects the typo in `cmsPage` from `seoDescription` (bugged) to `seoDesc` (Postgres database schema representation).
  - Queries `CmsConfig` key `"landing_pages_data"` for CMS MegaMenu category landing pages and extracts dynamic metadata.

### 2. Sitemap Generation
- Generates `sitemap.xml` automatically if it is missing on server boot.
- Fetches all active products, categories, blogs, static pages, published CMS pages, and all landing page keys under `landing_pages_data`.
- Appends all items to a structured `<urlset>` with customized priorities (`1.0` for home, `0.9` for products, `0.8` for categories, `0.7` for blogs/relief pages, `0.6` for general pages) and saves it to the persistent uploads folder `/app/seo/sitemap.xml`.

### 3. Duplicate Media Deletion
- Recursively scans the `/public/uploads/` directory on disk.
- Groups all files by MD5 checksum.
- Keeps the oldest file (`mtimeMs` ascending sort) as the original source of truth.
- For all duplicate paths, scans and updates references in the PostgreSQL database:
  - `Product`: `image` and `images` (array search and replace).
  - `Category`: `image`.
  - `Blog`: `cover`.
  - `CmsPage`: `seoImage`.
  - `User`: `avatar`.
  - `Review`: `images` (array search and replace).
- Deletes the duplicate file from the server disk and returns metrics.

### 4. Interactive Lightbox Preview
- Product form cover photo and gallery thumbnails have a **Maximize** overlay button.
- Clicking the button loads the image in a dark background overlay modal (`Dialog`).
- Round action icons allow zoom-in (+25% steps up to 300%), zoom-out (-25% steps down to 50%), and reset (back to 100%) with smooth transitions.

---

## 🧪 Testing and Verification

### GSC & Sitemap
1. Open GSC and enter the target URL under the URL Inspection tool.
2. Select **TEST LIVE URL** to verify Googlebot hits the live Caddyfile routing and picks up the correct user-specified canonical path.
3. Validate `/sitemap.xml` returns a `200 OK` with valid XML structure.

### Duplicate Media Deletion
- Call `DELETE /api/v1/media/duplicates` (or via Admin -> Storage -> Actions -> Delete Duplicate Photos).
- Confirm files are deleted and the response contains `dbReferencesUpdated` and `bytesSaved`.

### Zoomable Lightbox
- Go to Admin -> Products -> Edit Product.
- Click the top-left Zoom button on the Cover Image or any Gallery thumbnail to verify scale rendering.

### AI Quick Add Media Selector
- Go to Admin -> Products -> Quick Add.
- Click the "Media Library" button in any row, select an image, and verify it is successfully loaded into the row and previewed correctly.

### Saved Product Image Regeneration & Task Blocking
- Go to Admin -> Products -> Edit Product (on a saved/published product page).
- Verify the **Regenerate AI Images** button is visible in the Gallery header, and **Sparkles** icons are visible on hover over gallery images.
- Click the regenerate icon, provide an AI prompt, and confirm the new AI photo is generated and instantly loaded/saved.
- Trigger a regeneration, and verify that while it is running, other Sparkles buttons are hidden/disabled to prevent double execution.
- Refresh the page during regeneration, and verify that the loading state/loader spinner on the target image is successfully recovered and keeps polling until it finishes.

### Background Product Content Optimization
- Go to Admin -> Products -> Edit Product (on a saved product).
- Click the **Optimize with AI** button inside the Actions Card.
- Enter an optional prompt, and click Generate.
- Verify that a toast loader appears showing progress steps (`AI Optimization: Loading product details...`, `Optimizing...`, `Saving...`).
- Refresh the page during optimization, and verify that the page recovery hook automatically restores the loading toast and finishes the task in the background.
- Once completed, check that the optimized description, specifications, and SEO keywords/meta tags are updated and automatically reloaded in the form.

---

## 📦 Phase 1: Dual-Layer Inventory & Warehouse Database Migration (v1.0-ims)
- **Schema Updates (`backend/prisma/schema.prisma`)**:
  - Added enums: `WarehouseType`, `StockMovementType`, `POStatus`.
  - Added models: `Warehouse`, `InventoryItem`, `StockMovement`, `Supplier`, `PurchaseOrder`, `PurchaseOrderItem`, `StockTransfer`.
  - Updated relations on `User` and `ProductVariant`.
- **Database Synchronization**:
  - Applied schema to PostgreSQL via `npx prisma db push`.
  - Re-generated Prisma Client (v5.22.0) with updated query engine bindings.
- **Existing Catalog Migration (`backend/src/utils/migrateExistingProductsToInventory.ts`)**:
  - Created Central Main Warehouse (`WH-MAIN`).
  - Scanned all 24 existing real products in the PostgreSQL database.
  - Linked all 38 existing product variants into `InventoryItem` records with dual-layer stock (`quantityOnHand`, `webshopAllocated`), shelf/bin locations (`A-01-1`), and auto-generated machine QR payloads.
  - Recorded initial ledger entries in `StockMovement`.

---

## 📦 Phase 2: Backend Core Services, QR/Barcode Engine & APIs (v1.0-ims)
- **Services Added**:
  - `backend/src/services/qrBarcodeService.ts`: Standardized machine payload generator, high-res DataURL generator, and 1D Code-128 barcode buffer creator.
  - `backend/src/services/labelPrintService.ts`: Printable PDF label engine supporting continuous Thermal Roll (50x30mm) and standard A4 sheets (24/30 label grids).
  - `backend/src/services/inventoryService.ts`: Automatic catalog hook initializing and syncing variants and `InventoryItem` records on product creation/update.
- **Controller & Routes**:
  - `backend/src/controllers/inventoryController.ts` & `backend/src/routes/inventoryRoutes.ts`:
    - `GET /api/v1/inventory/admin/list` (paginated items with filters and global storage/webshop summary)
    - `GET /api/v1/inventory/admin/by-sku/:sku` (instant lookup for scanner)
    - `POST /api/v1/inventory/admin/adjust-storage` (physical count adjustment & audit logging)
    - `POST /api/v1/inventory/admin/allocate-webshop` (webshop quota allocation)
    - `PUT /api/v1/inventory/admin/items/:id/location` (shelf/bin location update)
    - `GET /api/v1/inventory/admin/qr-code/:id` (QR preview data)
    - `POST /api/v1/inventory/admin/labels/pdf` (stream printable PDF sticker sheet)
    - `GET /api/v1/inventory/admin/movements` (stock audit ledger)
- **Product Controller Integration (`backend/src/controllers/productController.ts`)**:
  - Connected `syncProductInventory` hook on product create and edit.
  - Included `inventoryItems` in `getProductBySlug` response.

---

## 📦 Phase 3: Frontend Admin UI, Product Form Hook & Translations (v1.0-ims)
- **Repository & Client**:
  - `frontend/src/client/inventoryRepository.ts`: Typed client repository for list, adjust, allocate, QR preview, PDF labels, and movements.
  - `frontend/src/utils/endpoints.ts`: Added inventory API endpoints.
- **Admin Pages & Routing**:
  - `frontend/src/pages/admin/AdminInventory.tsx`: Master Dual-Layer Dashboard with 3 View Tabs (`All Inventory`, `Storage Only`, `Webshop Channel`), 4 responsive metric summary cards, live search, low stock alert filter, responsive table with inline bin location edit, batch selection, and quick actions.
  - `frontend/src/App.tsx`: Registered `/admin/inventory` route.
  - `frontend/src/components/admin/AdminSidebar.tsx`: Added `Inventory` navigation link with `Boxes` icon.
  - `frontend/src/context/AdminContext.tsx`: Added `"inventory"` to superadmin, admin, and moderator permissions.
- **Product Edit/Create Form Integration (`AdminProductForm.tsx`)**:
  - Added **"📦 Inventory & Storage"** Card in the right sidebar.
  - Inputs for `storageStock` (Physical Godown), `webshopStock` (Live Website Quota), and `binLocation` (Shelf / Rack ID).
  - Added dynamic calculation and visual pill for `Offline Safety Reserve`.
  - Added quick `[🖨️ QR Label]` button opening `QrCodePreviewModal` directly from the product edit page.
  - Integrated inventory fields into form submission payload and product reload hook.
- **Interactive Modals**:
  - `StockAdjustmentModal.tsx`: Supports delta (+/-) and exact count modes with reason selection and custom notes.
  - `AllocateWebshopModal.tsx`: Visual dual-layer slider and publication toggle.
  - `QrCodePreviewModal.tsx`: QR preview with copy payload and single thermal label PDF generation.
  - `LabelPrintModal.tsx`: Batch label generator supporting Thermal Roll (50x30mm) and A4 sheets (24/30 labels/page) with price and bin location toggles.
- **Localization (100% Bilingual)**:
  - `frontend/src/locales/en/translation.json`: Full English translations for `admin_sidebar.inventory` and `inventory` namespace.
  - `frontend/src/locales/nl/translation.json`: Full Dutch translations for `admin_sidebar.inventory` and `inventory` namespace.
